<?php

namespace WF\API\Automation\Services;

use WF\API\Automation\Services\CreditParsers\BureauParserFactory;

/**
 * Example Usage
 *
 * $applicant = [
 * 'monthly_income' => 5000,
 * 'monthly_debt' => 1400,
 * 'employment_type' => 'W2',
 * 'state' => 'TX'
 * ];
 *
 * $vehicle = [
 * 'loan_type' => 'auto',
 * 'loan_amount' => 16000,
 * 'vehicle_value' => 19000,
 * 'vehicle_year' => 2023
 * ];
 *
 * // Raw credit bureau API response
 * $bureau = 'TransUnion';
 * $rawCreditPayload = getCreditDataFromTransUnionAPI();
 *
 * $lenderRules = getLenderRulesFromDatabase(); // Load as array
 *
 * $scorer = new RiskScorer($applicant, $vehicle, $bureau, $rawCreditPayload, $lenderRules);
 * $result = $scorer->calculate();
 *
 * print_r($result);
 *
 *  ---------OUTPUT --------
 * [
 * 'approval_score' => 0.76,
 * 'risk_tier' => 'B',
 * 'fico' => 695,
 * 'ltv' => 0.84,
 * 'dti' => 0.28,
 * 'matched_lenders' => ['Lender A', 'Lender B'],
 * 'credit_factors' => [
 * 'fico' => 695,
 * 'inquiries_6mo' => 2,
 * 'open_tradelines' => 7,
 * 'revolving_utilization' => 0.32,
 * 'estimated_monthly_debt' => 3567.88
 * 'delinquencies' => 1,
 * 'public_records' => 0
 * ]
 * ]
 *
 * ------ Bureau Parser ------
 * use App\Services\CreditParsers\BureauParserFactory;
 *
 * // Assume $payload is the raw API result from TransUnion
 * $bureau = 'TransUnion'; // or 'Experian', 'Equifax'
 * $parser = BureauParserFactory::create($bureau);
 * $creditData = $parser->parse($payload);
 *
 * print_r($creditData);
 *
 *
 */
use Log;
class RiskScorer
{
    private array $applicant;
    private array $vehicle;
    private array $lenderRules;
    private array $creditData;

    public function __construct(array $applicant, array $vehicle, string $bureau, array $rawPayload, array $lenderRules = [])
    {
        $this->applicant = $applicant;
        $this->vehicle = $vehicle;
        $this->lenderRules = $lenderRules;

        // Parse the raw credit payload from the selected bureau
        $parser = BureauParserFactory::create($bureau);
        $this->creditData = $parser->parse($rawPayload);
    }

    public function calculate(): array
    {
        $fico = $this->creditData['fico'] ?? null;
        $income = $this->applicant['monthly_income'] ?? null;
        $dti = $this->calculateDTI();
        $ltv = $this->calculateLTV();

        // Extract additional applicant data (with defaults
        $employmentType = $this->applicant['employment_type'] ?? 'W2';
        $state = $this->applicant['state'] ?? '';

        // Risk scoring logic
        $ficoScore = ($fico - 300) / 550;
        $dtiScore = max(0, 1 - ($dti / 0.4));
        $ltvScore = max(0, 1 - ($ltv / 1.2));
        $employmentScore = $employmentType === 'W2' ? 1 : 0.7;

        $rawScore = round(0.4 * $ficoScore + 0.25 * $dtiScore + 0.2 * $ltvScore + 0.15 * $employmentScore, 2);

        $tier = match (true) {
            $rawScore >= 0.85 => 'A',
            $rawScore >= 0.70 => 'B',
            $rawScore >= 0.50 => 'C',
            default => 'D',
        };

        $matched = $this->matchLenders($fico, $dti, $ltv, $employmentType, $state);
        $isComplete = $fico && $dti !== -1.0 && $ltv > 0;
        $reason = !$fico ? 'missing_fico' : (!$income ? 'missing_income' : null);

        return [
          'approval_score' => $isComplete ? $rawScore : null,
          'risk_tier' => $isComplete ? $tier : 'manual_review',
          'matched_lenders' => $isComplete ? $matched : [],
          'completeness_flag' => $isComplete ? 'complete' : 'incomplete',
          'missing_reason' => $reason,
          'fico' => $fico,
          'ltv' => round($ltv, 2),
          'dti' => round($dti, 2),
          'credit_factors' => $this->creditData
        ];
    }

    private function calculateDTI(): float
    {
        $income = $this->applicant['monthly_income'] ?? null;
        $manualDebt = $this->applicant['monthly_debt'] ?? null;

        // Attempt to pull debt from credit data if manual input not provided
        $estimatedDebt = $this->creditData['estimated_monthly_debt'] ?? null;
        $debt = $manualDebt ?? $estimatedDebt ?? 0;

        if ($income && $debt) {
            return $debt / $income;
        }

        // Can't calculate DTI accurately
        return -1.0; // Flag as invalid
    }


    private function calculateLTV(): float
    {
        $loanAmount = $this->vehicle['loan_amount'] ?? 1;
        $vehicleValue = $this->vehicle['vehicle_value'] ?? 1;
        return $loanAmount / $vehicleValue;
    }

    private function matchLenders(int $fico, float $dti, float $ltv, string $employmentType, string $state): array
    {
        $loanType = $this->vehicle['loan_type'] ?? 'auto';
        $matched = [];

        foreach ($this->lenderRules as $lender) {
            if (
              $fico >= $lender['min_fico'] &&
              $dti <= $lender['max_dti'] &&
              $ltv <= $lender['max_ltv'] &&
              in_array($loanType, $lender['loan_types']) &&
              in_array($state, $lender['states']) &&
              (!$lender['no_self_employed'] || $employmentType === 'W2')
            ) {
                $matched[] = $lender['name'];
            }
        }

        return $matched;
    }

}

