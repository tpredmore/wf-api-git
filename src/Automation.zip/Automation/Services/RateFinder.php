<?php

namespace WF\API\Automation\Services;

class RateFinder {
    public static function findRate(array $ratesPayload, int $vehicleYear, int $term, int $fico, ?int $ltv = null): array|false
    {
        $hasLtv = self::detectLtvStructure($ratesPayload);
        $yearGroup = self::matchYearGroup($ratesPayload, $vehicleYear);

        if (!$yearGroup || empty($yearGroup['rates'])) {
            return false;
        }

        $termBlock = self::matchTermBlock($yearGroup['rates'], $term);
        if (!$termBlock) {
            return false;
        }

        // Sort FICO descending so we match highest possible
        usort($termBlock['values'], fn($a, $b) => $b['fico'] <=> $a['fico']);

        foreach ($termBlock['values'] as $value) {
            if ($fico >= (int)$value['fico']) {
                if ($hasLtv && isset($value['ltv']) && is_array($value['ltv']) && $ltv !== null) {
                    // Sort LTV tiers ascending by max
                    usort($value['ltv'], fn($a, $b) => $a['max'] <=> $b['max']);

                    foreach ($value['ltv'] as $ltvTier) {
                        if ($ltv <= (int)$ltvTier['max'] && !empty($ltvTier['rate'])) {
                            return [
                              'year' => $yearGroup['year'],
                              'term' => $termBlock['term'],
                              'fico' => $fico,
                              'rate' => (float)$ltvTier['rate']
                            ];
                        }
                    }
                } elseif (!$hasLtv && isset($value['rate']) && (float)$value['rate'] > 0) {
                    return [
                      'year' => $yearGroup['year'],
                      'term' => $termBlock['term'],
                      'fico' => $fico,
                      'rate' => (float)$value['rate']
                    ];
                }
            }
        }

        return false;
    }

    private static function detectLtvStructure(array $ratesPayload): bool
    {
        foreach ($ratesPayload as $yearBlock) {
            foreach ($yearBlock['rates'] ?? [] as $termBlock) {
                foreach ($termBlock['values'] ?? [] as $value) {
                    if (isset($value['ltv']) && is_array($value['ltv']) && !empty($value['ltv'])) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static function matchYearGroup(array $ratesPayload, int $vehicleYear): array|null
    {
        $years = array_filter($ratesPayload, fn($item) => isset($item['year']));
        usort($years, fn($a, $b) => $a['year'] <=> $b['year']);

        foreach ($years as $group) {
            if ((int)$group['year'] >= $vehicleYear) {
                return $group;
            }
        }

        return end($years) ?: null;
    }

    private static function matchTermBlock(array $termBlocks, int $targetTerm): array|null
    {
        $terms = [];
        foreach ($termBlocks as $block) {
            if (isset($block['term'])) {
                $terms[(int)$block['term']] = $block;
            }
        }

        if (isset($terms[$targetTerm])) {
            return $terms[$targetTerm];
        }

        // Find the next higher term, or closest lower
        ksort($terms);
        foreach ($terms as $term => $block) {
            if ($term >= $targetTerm) {
                return $block;
            }
        }

        return end($terms) ?: null;
    }
}
