<?php

namespace WF\API\Automation\Services;

use WF\API\Automation\Services\Repository\LenderRepository;

class PrequalController {
    public static function evaluate(array $request): void
    {
        $applicant = [
          'monthly_income' => $request['monthly_income'],
          'monthly_debt' => $request['monthly_debt'],
          'employment_type' => $request['employment_type'],
          'state' => $request['state']
        ];

        $vehicle = [
          'loan_type' => $request['loan_type'],
          'loan_amount' => $request['loan_amount'],
          'vehicle_value' => $request['vehicle_value'],
          'vehicle_year' => $request['vehicle_year']
        ];

        $bureau = $request['bureau']; // e.g., 'transunion'
        $rawPayload = $request['credit_payload']; // from soft pull API

        // Retrieve lender rules (from DB or config)
        $lenderRules = LenderRepository::getActiveRules();

        // Run risk evaluation
        $scorer = new RiskScorer($applicant, $vehicle, $bureau, $rawPayload, $lenderRules);
        $result = $scorer->calculate();

        // Log, store, or return result
        http_response_code(200);
        echo json_encode($result);
    }
}