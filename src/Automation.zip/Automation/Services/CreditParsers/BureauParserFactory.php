<?php

namespace WF\API\Automation\Services\CreditParsers;

class BureauParserFactory {
    public static function create(string $bureau): BureauParserInterface {
        return match (strtolower($bureau)) {
            'transunion' => new TransUnionParser(),
            'experian' => new ExperianParser(),
            'equifax' => new EquifaxParser(),
            default => throw new \InvalidArgumentException("Unsupported bureau: $bureau")
        };
    }
}
