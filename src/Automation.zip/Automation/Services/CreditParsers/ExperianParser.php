<?php

namespace WF\API\Automation\Services\CreditParsers;

class ExperianParser implements BureauParserInterface {
    public function parse(array $payload): array {
        return [
          'fico' => $payload['riskModel']['ficoScore'] ?? null,
          'inquiries_6mo' => $payload['inquiries']['recentCount'] ?? 0,
          'open_tradelines' => count($payload['tradelines']['open'] ?? []),
          'estimated_monthly_debt' => $this->estimateDebtFromTradelines($payload['tradelines']['open'] ?? []),
          'revolving_utilization' => $payload['summary']['utilizationRate'] ?? 0.0,
          'delinquencies' => $payload['summary']['derogatoryCount'] ?? 0,
          'public_records' => $payload['publicRecords']['total'] ?? 0
        ];
    }

    private function estimateDebtFromTradelines(array $tradelines): float
    {
        $total = 0;
        foreach ($tradelines as $tradeline) {
            if (!empty($tradeline['monthlyPayment'])) {
                $total += $tradeline['monthlyPayment'];
            }
        }
        return $total;
    }
}
