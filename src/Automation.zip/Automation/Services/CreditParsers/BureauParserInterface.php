<?php

namespace WF\API\Automation\Services\CreditParsers;

interface BureauParserInterface {
    public function parse(array $payload): array;
}
