<?php

namespace WF\API\Automation\Services\CreditParsers;

class TransUnionParser implements BureauParserInterface {
    public function parse(array $payload): array {
        return [
          'fico' => $payload['fico_score'] ?? null,
          'inquiries_6mo' => $payload['inquiries_6mo'] ?? 0,
          'open_tradelines' => $payload['open_trade_count'] ?? 0,
          'open_auto_tradelines' => $payload['open_auto_trade_count'] ?? 0,
          'estimated_monthly_debt' => $this->estimateDebtFromTradelines($payload['trade_lines'] ?? []),
          'revolving_utilization' => 100 - $payload['revolving_available'],
          'collections' => $payload['collection_count'] ?? 0,
          'delinquencies' => $payload['now_delinquent'] ?? 0,
          'public_records' => is_array($payload['public_records']) ? count($payload['public_records']) : 0
        ];
    }

    private function estimateDebtFromTradelines(array $tradelines): float
    {
        $total = 0;
        foreach ($tradelines as $tradeline) {
            if ($tradeline['is_open'] && stripos(strtolower($tradeline['type']), 'mortgage') === false && !empty($tradeline['payment']) ) {
                $total += $tradeline['payment'];
            }
        }
        return $total;
    }
}
