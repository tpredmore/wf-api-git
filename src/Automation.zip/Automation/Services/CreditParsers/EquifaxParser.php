<?php

namespace WF\API\Automation\Services\CreditParsers;

class EquifaxParser implements BureauParserInterface {
    public function parse(array $payload): array {
        return [
          'fico' => $payload['equifaxScore']['ficoScore'] ?? null,
          'inquiries_6mo' => $payload['inquiriesSummary']['countLast6Months'] ?? 0,
          'open_tradelines' => $payload['tradelineStats']['openAccounts'] ?? 0,
          'estimated_monthly_debt' => $this->estimateDebtFromTradelines($payload['tradelineStats']['openAccounts'] ?? []),
          'revolving_utilization' => $payload['creditUsage']['revolvingUtilizationPct'] / 100 ?? 0.0,
          'delinquencies' => $payload['summary']['delinquencyCount'] ?? 0,
          'public_records' => $payload['publicRecords']['recordsFound'] ?? 0
        ];
    }

    private function estimateDebtFromTradelines(array $tradelines): float
    {
        $total = 0;
        foreach ($tradelines as $tradeline) {
            if (!empty($tradeline['monthlyPayment'])) {
                $total += $tradeline['monthlyPayment'];
            }
        }
        return $total;
    }
}
