<?php

namespace WF\API\Automation\Services\Repository;

class LenderRepository {

    public static function getActiveRules(): array {
        return []; // Placeholder for actual data fetching logic
    }

    public static function buildRules(array $lenders): array
    {
        $rules = [];

        foreach ($lenders as $lender) {
            if (!isset($lender['config']) || empty($lender['config'])) {
                continue;
            }

            $config = json_decode($lender['config'], true);

            // Skip if JSON is invalid
            if (!is_array($config)) {
                continue;
            }

            $rules[] = [
              'name' => $config['name'] ?? $lender['name'] ?? 'Unnamed Lender',
              'loan_types' => self::normalizeLoanTypes($config['type'] ?? ''),
              'min_fico' => (int)($config['min_fico'] ?? 0),
              'states' => $config['fom_state'] ?? [],
              'max_ltv' => self::parseMaxLTV($config['cash_out_ltv'] ?? '100'),
              'no_self_employed' => false // You can enhance with more config rules later
            ];
        }

        return $rules;
    }

    private static function normalizeLoanTypes(string $type): array
    {
        return match (strtolower($type)) {
            'auto' => ['auto'],
            'personal' => ['personal'],
            default => [$type]
        };
    }

    private static function parseMaxLTV(string $ltv): float
    {
        // Default to 100% if can't be parsed
        if (is_numeric($ltv)) {
            return (float) $ltv / 100;
        }

        // Attempt to extract max % from messy text like "Tier 1 740+ 120% ..."
        preg_match_all('/(\d{3,})[\s\w]*?(\d{2,3})%/', $ltv, $matches);

        if (!empty($matches[2])) {
            $max = max(array_map('intval', $matches[2]));
            return $max / 100;
        }

        return 1.0; // Fallback to 100%
    }
}