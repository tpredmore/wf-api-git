<?php

namespace WF\API\Automation;

use WF\API\Automation\Services\CreditParsers\BureauParserFactory;
use WF\API\Automation\Services\RiskScorer;
use Log;

class Automation
{

    protected Log $logger;

    public function __construct() {
        $this->logger = new Log;
    }


    public function handler ($json): array {
        $payload = json_decode('{
  "bureau": "experian",
  "hit": true,
  "pulled_at": "2025-06-25 14:16:44",
  "fico_score": "820",
  "has_coapp": false,
  "dti": 0,
  "open_trade_count": 4,
  "auto_trade_count": 1,
  "open_auto_trade_count": 1,
  "derogatory_marks": 0,
  "now_delinquent": 0,
  "was_delinquent": 0,
  "bankruptcies": 0,
  "past_due_amount": 0,
  "satisfactory_accounts": 4,
  "install_balance": 24118,
  "scheduled_payment": 1882,
  "real_estate_balance": 139409,
  "real_estate_payment": 1401,
  "revolving_balance": 1874,
  "revolving_limit": 33500,
  "revolving_available": 5,
  "paid_accounts": 0,
  "inquiries_6mo": 1,
  "oldest_trade": "12/2006",
  "score_data": {
    "score": "812",
    "percentile": "N/A",
    "model": "VantageScore 4",
    "evaluation": "N/A",
    "factors": [
      {
        "prio": "1",
        "code": "14",
        "desc": "Too high proportion of accounts recently opened"
      },
      {
        "prio": "2",
        "code": "64",
        "desc": "Not enough balance paid down over time on real estate secured loans"
      },
      {
        "prio": "3",
        "code": "48",
        "desc": "Lack of retail account information"
      },
      {
        "prio": "4",
        "code": "04",
        "desc": "Balances on accts too high compared to credit limits and loan amounts"
      },
      {
        "prio": "5",
        "code": "84",
        "desc": "Number of inquiries was a factor in determining the score"
      }
    ]
  },
  "identity_records": [
    {
      "first_name": "NATHANIEL",
      "last_name": "FORBES",
      "middle_name": "L",
      "dob": "",
      "ssn": ""
    }
  ],
  "address_records": [
    {
      "city": "SAINT PAUL",
      "state": "MN",
      "zip": "551022160",
      "first_reported": "1997-10-27",
      "source": "2",
      "address": "166NINAST",
      "current": false
    },
    {
      "city": "LONG BEACH",
      "state": "CA",
      "zip": "908531177",
      "first_reported": "2007-08-24",
      "source": "1",
      "address": "Box 41177UNKUNK",
      "current": false
    },
    {
      "city": "MINNEAPOLIS",
      "state": "MN",
      "zip": "554030311",
      "first_reported": "1990-12-11",
      "source": "1",
      "address": "PO BOX 3311UNKUNK",
      "current": false
    }
  ],
  "employment_records": [
    {
      "occupation": "",
      "name": "SELFEMPLOYED"
    }
  ],
  "public_records": [],
  "inquiries": [
    {
      "name": "BK OF AMER",
      "date": "2025-02-18",
      "number": "1197678",
      "code": "BB",
      "type": "00"
    }
  ],
  "collections": [],
  "trade_lines": [
    {
      "bureau": "experian",
      "opened": "2019-04-01",
      "is_open": true,
      "closed": "",
      "type": "Credit Card",
      "creditor": "BANK OF AMERICA",
      "subscriber_number": "1230206",
      "kind_of_business": "Bank Credit Cards",
      "joint": false,
      "ecoa": "Individual",
      "account_num": "",
      "status": "This is an account in good standing",
      "status_date": "2025-06-01",
      "standing": 1,
      "months_reported": "74",
      "balance": "302",
      "balance_date": "2025-06-15",
      "credit_limit": 26000,
      "payment": "25",
      "actual_payment": "",
      "past_due": "",
      "original_amount": "",
      "high_credit": "6818",
      "terms": "REV",
      "last_payment_date": "2025-06-01",
      "payment_history": "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC",
      "derogatory_30": "",
      "derogatory_60": "",
      "derogatory_90": "",
      "first_delinquency": "",
      "second_delinquency": "",
      "extra": "Evaluation Code: \"P\""
    },
    {
      "bureau": "experian",
      "opened": "2025-02-01",
      "is_open": true,
      "closed": "",
      "type": "Auto Loan",
      "creditor": "BANK OF AMERICA, N.A.",
      "subscriber_number": "1198830",
      "kind_of_business": "All Banks - Non-Specific",
      "joint": true,
      "ecoa": "Joint Account",
      "account_num": "65010069693826",
      "status": "This is an account in good standing",
      "status_date": "2025-05-01",
      "standing": 1,
      "months_reported": "4",
      "balance": "24118",
      "balance_date": "2025-05-31",
      "credit_limit": "",
      "payment": "431",
      "actual_payment": "",
      "past_due": "",
      "original_amount": "24793",
      "high_credit": "",
      "terms": "72",
      "last_payment_date": "2025-05-01",
      "payment_history": "CCCC",
      "derogatory_30": "",
      "derogatory_60": "",
      "derogatory_90": "",
      "first_delinquency": "",
      "second_delinquency": "",
      "extra": "Evaluation Code: \"P\""
    },
    {
      "bureau": "experian",
      "opened": "2021-06-01",
      "is_open": true,
      "closed": "",
      "type": "Conventional Real Estate Loan, Including Purchase Money First",
      "creditor": "BREMER BANK",
      "subscriber_number": "2160523",
      "kind_of_business": "All Banks - Non-Specific",
      "joint": true,
      "ecoa": "Joint Account",
      "account_num": "210405218300003",
      "status": "This is an account in good standing",
      "status_date": "2025-05-01",
      "standing": 1,
      "months_reported": "48",
      "balance": "139409",
      "balance_date": "2025-05-31",
      "credit_limit": "",
      "payment": "1401",
      "actual_payment": "",
      "past_due": "",
      "original_amount": "155000",
      "high_credit": "",
      "terms": "360",
      "last_payment_date": "2025-05-01",
      "payment_history": "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC",
      "derogatory_30": "",
      "derogatory_60": "",
      "derogatory_90": "",
      "first_delinquency": "",
      "second_delinquency": "",
      "extra": "Evaluation Code: \"P\""
    },
    {
      "bureau": "experian",
      "opened": "2006-12-01",
      "is_open": true,
      "closed": "",
      "type": "Credit Card",
      "creditor": "CAPITAL ONE",
      "subscriber_number": "1270246",
      "kind_of_business": "Bank Credit Cards",
      "joint": false,
      "ecoa": "Individual",
      "account_num": "",
      "status": "This is an account in good standing",
      "status_date": "2025-05-01",
      "standing": 1,
      "months_reported": "99",
      "balance": "1572",
      "balance_date": "2025-05-24",
      "credit_limit": 7500,
      "payment": "25",
      "actual_payment": "",
      "past_due": "",
      "original_amount": "",
      "high_credit": "17177",
      "terms": "REV",
      "last_payment_date": "2025-05-01",
      "payment_history": "CCCCCCCCCCCCCCCCC00C00CCC0000C0C000CCCCC00000000000000000000000000CCCCCCCCCCCCCCCCCC",
      "derogatory_30": "",
      "derogatory_60": "",
      "derogatory_90": "",
      "first_delinquency": "",
      "second_delinquency": "",
      "extra": "Evaluation Code: \"P\""
    }
  ],
  "bureau_errors": [],
  "bureau_alerts": [
    "V484NUMBER OF INQUIRIES WAS A FACTOR IN DETERMINING THE SCORE"
  ],
  "report_date": "062525",
  "bureau_address": "P.O. Box 2104, Allen, TX 75013",
  "bureau_phone": "888-397-3742",
  "is_coapp": false
}', TRUE);

        // Log::debug(print_r($payload,true));

        // Assume $payload is the raw API result from TransUnion
        $bureau = 'TransUnion'; // or 'Experian', 'Equifax'
        $parser = BureauParserFactory::create($bureau);
        $rawCreditPayload = $parser->parse($payload);

        $this->logger->debug(print_r($rawCreditPayload, TRUE));

        $applicant = [
          'monthly_income' => 10000,
          'monthly_debt' => NULL,
          'employment_type' => 'W2',
          'state' => 'TX'
        ];

        $vehicle = [
          'loan_type' => 'auto',
          'loan_amount' => 37500,
          'vehicle_value' => 43000,
          'vehicle_year' => 2024
        ];

        $lenderRules = []; // Load as an array

        $scorer = new RiskScorer($applicant, $vehicle, $bureau, $payload, $lenderRules);
        $result = $scorer->calculate();

        Log::debug(print_r($result, TRUE));

        return [
          'success' => true,
          'error' => null,
          'data' => $result
        ];
    }
}
