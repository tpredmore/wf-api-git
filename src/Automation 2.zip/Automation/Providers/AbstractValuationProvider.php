<?php

declare(strict_types=1);

namespace WF\API\Automation\Providers;

use WF\API\Automation\Contracts\ValuationProviderInterface;
use Curl;
use Log;

abstract class AbstractValuationProvider implements ValuationProviderInterface
{
    protected array $config;

    public function __construct(
      protected Curl $httpClient,
      protected Log $logger,
      array $config = []
    ) {
        $this->config = $config;
    }

    abstract protected function makeValuationRequest(string $vin, int $mileage, string $zipCode, string $condition): array;
    abstract protected function parseValuationResponse(array $response): array;

    public function getValuation(string $vin, int $mileage, string $zipCode, string $condition = 'good'): array
    {
        try {
            $this->logger->info("Getting valuation from {$this->getProviderName()}", [
              'vin' => substr($vin, 0, 8) . '...',
              'mileage' => $mileage,
              'condition' => $condition
            ]);

            $response = $this->makeValuationRequest($vin, $mileage, $zipCode, $condition);
            return $this->parseValuationResponse($response);

        } catch (\Throwable $e) {
            $this->logger->warning("Valuation failed for {$this->getProviderName()}", [
              'error' => $e->getMessage()
            ]);

            return [
              'value' => 0,
              'source' => $this->getProviderName(),
              'error' => $e->getMessage(),
              'success' => false
            ];
        }
    }

    public function isAvailable(): bool
    {
        return !empty($this->config['api_key']) && !empty($this->config['endpoint']);
    }
}
