<?php

declare(strict_types=1);

namespace WF\API\Automation\Parsers;

use WF\API\Automation\Contracts\CreditParserInterface;
use WF\API\Automation\Models\CreditProfile;

abstract class AbstractCreditParser implements CreditParserInterface
{
    protected function calculateRevolvingUtilization(array $tradeLines): float
    {
        $totalBalance = 0;
        $totalLimit = 0;

        foreach ($tradeLines as $trade) {
            if (($trade['type'] ?? '') === 'Credit Card' && isset($trade['credit_limit'], $trade['balance'])) {
                $totalBalance += (float)$trade['balance'];
                $totalLimit += (float)$trade['credit_limit'];
            }
        }

        return $totalLimit > 0 ? $totalBalance / $totalLimit : 0.0;
    }

    protected function estimateMonthlyDebt(array $tradeLines): int
    {
        $totalPayment = 0;

        foreach ($tradeLines as $trade) {
            if (($trade['is_open'] ?? false) && isset($trade['payment'])) {
                $payment = (float)$trade['payment'];
                if ($payment > 0) {
                    $totalPayment += $payment;
                }
            }
        }

        return (int)$totalPayment;
    }

    protected function extractScoreFactors(array $rawData): array
    {
        $factors = [];

        if (isset($rawData['score_data']['factors'])) {
            foreach ($rawData['score_data']['factors'] as $factor) {
                $factors[] = [
                  'priority' => $factor['prio'] ?? '',
                  'code' => $factor['code'] ?? '',
                  'description' => $factor['desc'] ?? '',
                ];
            }
        }

        return $factors;
    }
}
