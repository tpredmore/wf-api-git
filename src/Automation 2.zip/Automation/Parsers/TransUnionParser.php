<?php

declare(strict_types=1);

namespace WF\API\Automation\Parsers;

use WF\API\Automation\Models\CreditProfile;

class TransUnionParser extends AbstractCreditParser
{
    public function parse(array $rawData): CreditProfile
    {
        // Parse TransUnion-specific response structure
        $report = $rawData['creditReport'] ?? $rawData;

        return CreditProfile::fromArray([
          'fico_score' => $this->extractTransUnionScore($report),
          'bureau' => 'transunion',
          'open_trade_count' => $this->countOpenAccounts($report),
          'auto_trade_count' => $this->countAutoLoans($report),
          'derogatory_marks' => $this->countDerogatory($report),
          'bankruptcies' => $this->countBankruptcies($report),
          'revolving_utilization' => $this->calculateRevolvingUtilization($this->extractTrades($report)),
          'inquiries_6mo' => $this->countRecentInquiries($report),
          'estimated_monthly_debt' => $this->estimateMonthlyDebt($this->extractTrades($report)),
          'trade_lines' => $this->extractTrades($report),
          'score_factors' => $this->extractTransUnionFactors($report),
          'hit' => !empty($report),
          'pulled_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function getSupportedBureau(): string
    {
        return 'transunion';
    }

    private function extractTransUnionScore(array $report): ?int
    {
        return isset($report['vantageScore']) ? (int)$report['vantageScore'] : null;
    }

    private function countOpenAccounts(array $report): int
    {
        $accounts = $report['tradelines'] ?? [];
        return count(array_filter($accounts, fn($account) =>
          ($account['accountCondition'] ?? '') === 'Open'
        ));
    }

    private function countAutoLoans(array $report): int
    {
        $accounts = $report['tradelines'] ?? [];
        return count(array_filter($accounts, fn($account) =>
        in_array($account['accountType'] ?? '', ['Auto Loan', 'Vehicle Loan'])
        ));
    }

    private function countDerogatory(array $report): int
    {
        // Implementation for TransUnion derogatory count
        return 0; // Placeholder
    }

    private function countBankruptcies(array $report): int
    {
        $publicRecords = $report['publicRecords'] ?? [];
        return count(array_filter($publicRecords, fn($record) =>
          ($record['type'] ?? '') === 'Bankruptcy'
        ));
    }

    private function countRecentInquiries(array $report): int
    {
        $inquiries = $report['inquiries'] ?? [];
        $sixMonthsAgo = new \DateTime('-6 months');

        return count(array_filter($inquiries, function($inquiry) use ($sixMonthsAgo) {
            $inquiryDate = \DateTime::createFromFormat('Y-m-d', $inquiry['dateOfInquiry'] ?? '');
            return $inquiryDate && $inquiryDate >= $sixMonthsAgo;
        }));
    }

    private function extractTrades(array $report): array
    {
        return $report['tradelines'] ?? [];
    }

    private function extractTransUnionFactors(array $report): array
    {
        return $report['scoreFactors'] ?? [];
    }
}
