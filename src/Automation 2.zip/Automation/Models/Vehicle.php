<?php

declare(strict_types=1);

namespace WF\API\Automation\Models;

use WF\API\Automation\Exceptions\ValidationException;

readonly class Vehicle
{
    public function __construct(
      public string $vin,
      public int $year,
      public string $make,
      public string $model,
      public int $mileage,
      public float $loanAmount,
      public ?float $vehicleValue = null,
      public string $condition = 'good'
    ) {
        $this->validate();
    }

    public static function fromArray(array $data): self
    {
        return new self(
          vin: $data['vin'] ?? '',
          year: (int)($data['year'] ?? 0),
          make: $data['make'] ?? '',
          model: $data['model'] ?? '',
          mileage: (int)($data['mileage'] ?? 0),
          loanAmount: (float)($data['loan_amount'] ?? 0),
          vehicleValue: isset($data['vehicle_value']) ? (float)$data['vehicle_value'] : null,
          condition: $data['condition'] ?? 'good'
        );
    }

    private function validate(): void
    {
        if (strlen($this->vin) !== 17) {
            throw new ValidationException('VIN must be exactly 17 characters');
        }

        if ($this->year < 1980 || $this->year > (date('Y') + 1)) {
            throw new ValidationException('Invalid vehicle year');
        }

        if ($this->loanAmount <= 0) {
            throw new ValidationException('Loan amount must be greater than 0');
        }

        if ($this->mileage < 0) {
            throw new ValidationException('Mileage cannot be negative');
        }
    }

    public function calculateLTV(): float
    {
        if ($this->vehicleValue === null || $this->vehicleValue <= 0) {
            return 0.0;
        }

        return $this->loanAmount / $this->vehicleValue;
    }

    public function getAgeInYears(): int
    {
        return (int)date('Y') - $this->year;
    }
}
