<?php

declare(strict_types=1);

namespace WF\API\Automation\Exceptions;

class ValidationException extends AutomationException {}
