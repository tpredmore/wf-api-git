<?php

declare(strict_types=1);

namespace WF\API\Automation\Services;

use WF\API\Automation\Contracts\PreQualEngineInterface;
use WF\API\Automation\Contracts\BureauClientInterface;
use WF\API\Automation\Contracts\CreditParserInterface;
use WF\API\Automation\Contracts\RiskScorerInterface;
use WF\API\Automation\Contracts\ValuationProviderInterface;
use WF\API\Automation\Models\Applicant;
use WF\API\Automation\Models\Vehicle;
use WF\API\Automation\Models\CreditProfile;
use WF\API\Automation\Models\PreQualResult;
use WF\API\Automation\Factories\BureauClientFactory;
use WF\API\Automation\Factories\CreditParserFactory;
use WF\API\Automation\Factories\ValuationProviderFactory;
use WF\API\Automation\Exceptions\AutomationException;
use Log;

class PreQualEngine implements PreQualEngineInterface
{
    public function __construct(
      private RiskScorerInterface $riskScorer,
      private BureauClientFactory $bureauFactory,
      private CreditParserFactory $parserFactory,
      private ValuationProviderFactory $valuationFactory,
      private Log $logger
    ) {}

    /**
     * @throws \WF\API\Automation\Exceptions\AutomationException
     */
    public function evaluate(Applicant $applicant, Vehicle $vehicle, array $additionalData = []): PreQualResult
    {
        $bureau = $additionalData['preferred_bureau'] ?? 'experian';

        try {
            // Step 1: Pull credit report
            $creditProfile = $this->pullCreditReport($applicant, $bureau);

            // Step 2: Get vehicle valuation if not provided
            $vehicleWithValue = $this->ensureVehicleValuation($vehicle);

            // Step 3: Calculate risk score and match lenders
            $riskScore = $this->riskScorer->calculateScore($applicant, $vehicleWithValue, $creditProfile);
            $riskTier = $this->riskScorer->getRiskTier($riskScore);
            $matchedLenders = $this->riskScorer->matchLenders($applicant, $vehicleWithValue, $creditProfile);

            // Step 4: Determine completeness
            $isComplete = $this->isResultComplete($creditProfile, $applicant, $vehicleWithValue);
            $missingReason = $isComplete ? null : $this->getMissingReason($creditProfile, $applicant, $vehicleWithValue);

            return new PreQualResult(
              approvalScore: $isComplete ? $riskScore : 0.0,
              riskTier: $isComplete ? $riskTier : 'manual_review',
              matchedLenders: $isComplete ? $matchedLenders : [],
              isComplete: $isComplete,
              missingReason: $missingReason,
              creditProfile: $creditProfile,
              ltv: $vehicleWithValue->calculateLTV(),
              dti: $applicant->calculateDTI($creditProfile->estimatedMonthlyDebt),
              metadata: [
                'bureau_used' => $bureau,
                'score_factors' => $this->riskScorer->getScoreFactors(),
                'processing_time' => microtime(true) - ($_SERVER['REQUEST_TIME_FLOAT'] ?? 0)
              ]
            );

        } catch (\Throwable $e) {
            $this->logger->error('PreQual engine evaluation failed', print_r([
              'applicant_state' => $applicant->state,
              'vehicle_year' => $vehicle->year,
              'error' => $e->getMessage()
            ],true));

            throw new AutomationException('Failed to evaluate pre-qualification', 0, $e);
        }
    }

    /**
     * @throws \WF\API\Automation\Exceptions\AutomationException
     */
    private function pullCreditReport(Applicant $applicant, string $bureau): CreditProfile
    {
        $client = $this->bureauFactory->create($bureau);
        $parser = $this->parserFactory->create($bureau);

        $consumers = [
          [
            'firstName' => $applicant->firstName,
            'lastName' => $applicant->lastName,
            'ssn' => $applicant->ssn,
            'address' => $applicant->address,
            'city' => $applicant->city,
            'state' => $applicant->state,
            'zip' => $applicant->zipCode,
            'dob' => $applicant->dateOfBirth,
          ]
        ];

        if ($applicant->hasCoApplicant()) {
            $coApp = $applicant->coApplicant;
            $consumers[] = [
              'firstName' => $coApp['first_name'],
              'lastName' => $coApp['last_name'],
              'ssn' => $coApp['ssn'],
              'address' => $coApp['address'],
              'city' => $coApp['city'],
              'state' => $coApp['state'],
              'zip' => $coApp['zip'],
              'dob' => $coApp['dob'],
            ];
        }

        $rawResponse = $client->pullCreditReport($consumers);
        return $parser->parse($rawResponse);
    }

    /**
     * @throws \WF\API\Automation\Exceptions\ValuationException
     */
    private function ensureVehicleValuation(Vehicle $vehicle): Vehicle
    {
        if ($vehicle->vehicleValue !== null) {
            return $vehicle;
        }

        $provider = $this->valuationFactory->createBest();
        $valuation = $provider->getValuation($vehicle->vin, $vehicle->mileage, '', $vehicle->condition);

        return new Vehicle(
          vin: $vehicle->vin,
          year: $vehicle->year,
          make: $vehicle->make,
          model: $vehicle->model,
          mileage: $vehicle->mileage,
          loanAmount: $vehicle->loanAmount,
          vehicleValue: (float)$valuation['value'],
          condition: $vehicle->condition
        );
    }

    private function isResultComplete(CreditProfile $credit, Applicant $applicant, Vehicle $vehicle): bool
    {
        return $credit->hasValidScore()
          && $applicant->monthlyIncome > 0
          && $vehicle->vehicleValue > 0;
    }

    private function getMissingReason(CreditProfile $credit, Applicant $applicant, Vehicle $vehicle): string
    {
        if (!$credit->hasValidScore()) return 'missing_fico';
        if ($applicant->monthlyIncome <= 0) return 'missing_income';
        if ($vehicle->vehicleValue <= 0) return 'missing_vehicle_value';
        return 'unknown';
    }
}
