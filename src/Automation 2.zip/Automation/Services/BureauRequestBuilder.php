<?php

declare(strict_types=1);

namespace WF\API\Automation\Services;

use WF\API\Automation\Models\Applicant;

/**
 * Builds bureau-specific request payloads from applicant data
 */
class BureauRequestBuilder
{
    public function buildEquifaxRequest(Applicant $applicant, string $scoreModel = 'VANTAGE'): array
    {
        $consumers = [
          'name' => [
            [
              'identifier' => 'Current',
              'firstName' => $applicant->firstName,
              'lastName' => $applicant->lastName
            ]
          ],
          'dateOfBirth' => $this->formatDateForEquifax($applicant->dateOfBirth),
          'addresses' => [
            [
              'identifier' => 'Current',
              'city' => $applicant->city,
              'state' => $applicant->state,
              'zip' => $applicant->zipCode
            ]
          ]
        ];

        // Add SSN if available
        if (!empty($applicant->ssn)) {
            $consumers['socialNum'] = [
              [
                'identifier' => 'Current',
                'number' => str_replace('-', '', $applicant->ssn)
              ]
            ];
        }

        // Add co-applicant if present
        if ($applicant->hasCoApplicant()) {
            $coApp = $applicant->coApplicant;

            $consumers['name'][] = [
              'identifier' => 'Co-applicant',
              'firstName' => $coApp['first_name'],
              'lastName' => $coApp['last_name']
            ];

            if (!empty($coApp['ssn'])) {
                $consumers['socialNum'][] = [
                  'identifier' => 'Co-applicant',
                  'number' => str_replace('-', '', $coApp['ssn'])
                ];
            }

            $consumers['addresses'][] = [
              'identifier' => 'Co-applicant',
              'city' => $coApp['city'],
              'state' => $coApp['state'],
              'zip' => $coApp['zip']
            ];
        }

        return [
          'consumers' => $consumers,
          'customerReferenceIdentifier' => 'JSON',
          'customerConfiguration' => [
            'equifaxUSConsumerCreditReport' => [
              'memberNumber' => $_ENV['EQUIFAX_MEMBER_NUMBER'],
              'securityCode' => $_ENV['EQUIFAX_SECURITY_CODE'],
              'codeDescriptionRequired' => true,
              'ECOAInquiryType' => $applicant->hasCoApplicant() ? 'Co-applicant' : 'Individual',
              'models' => [['identifier' => $this->getEquifaxModelId($scoreModel)]],
              'optionalFeatureCode' => [$this->getEquifaxFeatureCode($scoreModel)],
              'vendorIdentificationCode' => 'FI',
              'pdfComboIndicator' => 'N'
            ]
          ]
        ];
    }

    public function buildExperianRequest(Applicant $applicant): array
    {
        return [
          'consumerPii' => [
            'primaryApplicant' => [
              'name' => [
                'firstName' => $applicant->firstName,
                'lastName' => $applicant->lastName,
              ],
              'ssn' => $applicant->ssn,
              'dob' => $applicant->dateOfBirth,
              'currentAddress' => [
                'line1' => $applicant->address,
                'city' => $applicant->city,
                'state' => $applicant->state,
                'zipCode' => $applicant->zipCode,
              ],
            ],
          ],
          'requestor' => [
            'subscriberCode' => $_ENV['EXPERIAN_SUBSCRIBER_CODE'] ?? '',
          ],
          'permissiblePurpose' => [
            'type' => 'ApplicationForCredit',
            'terms' => $applicant->hasCoApplicant() ? 'Joint' : 'Individual',
          ],
          'addOns' => [
            'scoreCard' => 'FICO',
          ],
        ];
    }

    public function buildTransUnionRequest(Applicant $applicant): array
    {
        return [
          'accountName' => $_ENV['TRANSUNION_ACCOUNT_NAME'] ?? '',
          'accountNumber' => $_ENV['TRANSUNION_ACCOUNT_NUMBER'] ?? '',
          'memberCode' => $_ENV['TRANSUNION_MEMBER_CODE'] ?? '',
          'subject' => [
            'name' => [
              'unparsedName' => $applicant->firstName . ' ' . $applicant->lastName,
            ],
            'ssn' => $applicant->ssn,
            'dateOfBirth' => $applicant->dateOfBirth,
            'address' => [
              'streetName' => $applicant->address,
              'city' => $applicant->city,
              'state' => $applicant->state,
              'zipCode' => $applicant->zipCode,
            ],
          ],
          'type' => 'identity',
          'showVantageScore' => true,
        ];
    }

    private function formatDateForEquifax(string $date): string
    {
        // Convert YYYY-MM-DD to MMDDYYYY
        $dateObj = \DateTime::createFromFormat('Y-m-d', $date);
        return $dateObj ? $dateObj->format('mdY') : '';
    }

    private function getEquifaxModelId(string $scoreModel): string
    {
        return match (strtoupper($scoreModel)) {
            'FICO' => '05483',
            'VANTAGE' => '05402',
            default => '05402'
        };
    }

    private function getEquifaxFeatureCode(string $scoreModel): string
    {
        return match (strtoupper($scoreModel)) {
            'FICO' => 'V', // EDAS & FICO Score based on Equifax Data
            'VANTAGE' => 'Z', // Enhanced Delinquency Alert System (EDAS)
            default => 'Z'
        };
    }
}
