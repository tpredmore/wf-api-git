<?php

declare(strict_types=1);

namespace WF\API\Automation\Http\Controllers;

use WF\API\Automation\AutomationService;
use WF\API\Automation\Models\Applicant;
use WF\API\Automation\Models\Vehicle;
use WF\API\Automation\Exceptions\AutomationException;
use WF\API\Automation\Exceptions\ValidationException;
use Log;

class PreQualController
{
    public function __construct(
      private AutomationService $automationService,
      private Log $logger
    ) {}

    public function handlePreQual( $request): array {
        try {
            // Get request data
            $requestData = $request->data;

            // Process pre-qualification
            $result = $this->automationService->processPreQual($requestData);

            return [
              'success' => true,
              'data' => $result->toArray(),
              'error' => ''
            ];

        } catch (ValidationException $e) {
            return [
              'success' => false,
              'data' => '',
              'error' => $e->getMessage()
            ];
        } catch (AutomationException $e) {
            $this->logger->error('PreQual processing failed', [
              'error' => $e->getMessage(),
              'context' => $e->getContext()
            ]);
            return [
              'success' => false,
              'data' => '',
              'error' => 'Processing failed - ' . $e->getMessage()
            ];
        } catch (\Throwable $e) {
            $this->logger->error('Unexpected error in PreQual', [
              'error' => $e->getMessage(),
              'trace' => $e->getTraceAsString()
            ]);
            return [
              'success' => false,
              'data' => '',
              'error' => 'Internal server error - ' . $e->getMessage()
            ];
        }
    }
}

// Migration Guide and Usage Examples

/*
=================================================================
MIGRATION GUIDE: From Old to New Architecture
=================================================================

STEP 1: Update your main handler
OLD CODE (Automation.php):
*/

// OLD - Remove this
/*
public function handler($json): array {
    $payload = json_decode('{...hardcoded json...}', TRUE);

    $bureau = 'TransUnion';
    $parser = BureauParserFactory::create($bureau);
    $rawCreditPayload = $parser->parse($payload);

    $scorer = new RiskScorer($applicant, $vehicle, $bureau, $payload, $lenderRules);
    $result = $scorer->calculate();

    return ['success' => true, 'data' => $result];
}
*/

// NEW - Use this instead
/*
public function handler(array $requestData): array {
    try {
        $automationService = $this->container->get(AutomationService::class);
        $result = $automationService->processPreQual($requestData);

        return [
            'success' => true,
            'data' => $result->toArray()
        ];
    } catch (\Throwable $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/*
STEP 2: Update your request format
OLD FORMAT:
*/

// OLD request format - don't use
/*
$requestData = [
    'monthly_income' => 10000,
    'monthly_debt' => null,
    'employment_type' => 'W2',
    'state' => 'TX',
    'loan_amount' => 37500,
    'vehicle_value' => 43000,
    'vehicle_year' => 2024
];
*/

// NEW request format - use this
/*
$requestData = [
    'applicant' => [
        'monthly_income' => 10000,
        'monthly_debt' => null,
        'employment_type' => 'W2',
        'state' => 'TX',
        'first_name' => 'John',
        'last_name' => 'Doe',
        'ssn' => '123456789',
        'address' => '123 Main St',
        'city' => 'Dallas',
        'zip_code' => '75201',
        'date_of_birth' => '1980-01-01'
    ],
    'vehicle' => [
        'vin' => '1HGBH41JXMN109186',
        'year' => 2024,
        'make' => 'Honda',
        'model' => 'Accord',
        'mileage' => 15000,
        'loan_amount' => 37500,
        'vehicle_value' => 43000,
        'condition' => 'good'
    ],
    'preferred_bureau' => 'experian'
];

/*
STEP 3: Update your DI container usage
Replace your old service instantiation with:
*/

// In your route or controller
/*
$container = // your DI container
$automationService = $container->get(AutomationService::class);

// Process the request
$result = $automationService->processPreQual($requestData);

/*
STEP 4: Example API Endpoint
Here's how to create a clean API endpoint:
*/

// routes/api.php or similar
/*
$app->post('/api/prequal', function (Request $request, Response $response) use ($container) {
    $controller = $container->get(PreQualController::class);
    return $controller->handlePreQual($request, $response);
});

/*
STEP 5: Testing the new architecture
*/

// Example test
/*
use WF\API\Automation\AutomationService;
use WF\API\Automation\Models\Applicant;
use WF\API\Automation\Models\Vehicle;

// Create test data
$requestData = [
    'applicant' => [
        'monthly_income' => 8000,
        'employment_type' => 'W2',
        'state' => 'TX',
        'first_name' => 'Jane',
        'last_name' => 'Smith',
        'ssn' => '987654321',
        'address' => '456 Oak Ave',
        'city' => 'Austin',
        'zip_code' => '78701',
        'date_of_birth' => '1985-05-15'
    ],
    'vehicle' => [
        'vin' => '1FTFW1ET5DFC12345',
        'year' => 2023,
        'make' => 'Ford',
        'model' => 'F-150',
        'mileage' => 25000,
        'loan_amount' => 45000,
        'condition' => 'excellent'
    ]
];

// Process through new service
$automationService = $container->get(AutomationService::class);
$result = $automationService->processPreQual($requestData);

// Check results
assert($result->isApproved() === true);
assert($result->getRiskTier() === 'B');
assert(count($result->getMatchedLenders()) > 0);

/*
=================================================================
BENEFITS OF THE NEW ARCHITECTURE:
=================================================================

1. ✅ Type Safety: All inputs validated through value objects
2. ✅ Testability: Dependency injection makes unit testing easy
3. ✅ Extensibility: Easy to add new bureaus, valuation providers
4. ✅ Maintainability: Clear separation of concerns
5. ✅ Error Handling: Proper exception hierarchy with context
6. ✅ Logging: Comprehensive logging throughout the process
7. ✅ Configuration: Environment-based configuration
8. ✅ Performance: Efficient token caching for bureau APIs

=================================================================
NEXT STEPS:
=================================================================

1. Set up your environment variables (.env file)
2. Test the new AutomationService with sample data
3. Gradually migrate existing endpoints to use new controllers
4. Implement your actual bureau API credentials
5. Add valuation provider API keys
6. Set up proper logging configuration
7. Write unit tests for critical components
8. Monitor performance and add caching as needed

=================================================================
TROUBLESHOOTING:
=================================================================

Common Issues:
- "Class not found": Check PSR-4 autoloading in composer.json
- "Missing environment variables": Ensure .env is properly loaded
- "Bureau API failures": Check credentials and endpoint URLs
- "DI Container errors": Verify all dependencies are properly configured

Debug Tips:
- Enable debug logging to see detailed request/response data
- Use try/catch blocks around AutomationService calls
- Check the metadata in PreQualResult for processing details
- Validate input data format matches the new structure
*/