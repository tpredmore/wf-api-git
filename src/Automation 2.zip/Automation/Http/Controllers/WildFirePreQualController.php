<?php
// src/Automation/Http/Controllers/WildFirePreQualController.php

declare(strict_types=1);

namespace WF\API\Automation\Http\Controllers;

use WF\API\Automation\AutomationService;
use WF\API\Automation\Adapters\ApplicationPayloadParser;
use WF\API\Automation\Formatters\WildFireBureauFormatter;
use WF\API\Automation\Models\Applicant;
use WF\API\Automation\Exceptions\AutomationException;
use WF\API\Automation\Exceptions\ValidationException;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Log\LoggerInterface;

/**
 * Controller specifically for WildFire LOS integration
 */
class WildFirePreQualController
{
    public function __construct(
      private AutomationService $automationService,
      private ApplicationPayloadParser $payloadParser,
      private WildFireBureauFormatter $wildFireFormatter,
      private LoggerInterface $logger
    ) {}

    /**
     * Handle pre-qualification request with WildFire application payload
     */
    public function handleWildFirePreQual(Request $request, Response $response): Response
    {
        try {
            // Parse the WildFire application payload
            $applicationData = $this->getApplicationPayload($request);

            // Extract applicant and vehicle data
            $applicant = $this->payloadParser->parseApplicant($applicationData);
            $vehicle = $this->payloadParser->parseVehicle($applicationData);
            $preferredBureau = $this->payloadParser->extractBureauPreference($applicationData);

            // Build request data for automation service
            $requestData = [
              'applicant' => $applicant->toArray(),
              'vehicle' => $vehicle->toArray(),
              'preferred_bureau' => $preferredBureau,
              'request_id' => $applicationData['application_id'] ?? uniqid()
            ];

            // Process through automation service
            $result = $this->automationService->processPreQual($requestData);

            // Format response in WildFire format
            $wildFireResponse = $this->wildFireFormatter->formatToWildFire(
              $result->creditProfile,
              [], // Raw bureau data would be passed here
              $applicant->hasCoApplicant()
            );

            // Return WildFire compatible response
            $responseData = [
              'success' => true,
              'error' => null,
              'bureau_payload' => [], // Raw bureau response
              'payload' => $wildFireResponse
            ];

            $response->getBody()->write(json_encode($responseData));
            return $response
              ->withHeader('Content-Type', 'application/json')
              ->withStatus(200);

        } catch (ValidationException $e) {
            return $this->errorResponse($response, $e->getMessage(), 400);
        } catch (AutomationException $e) {
            $this->logger->error('WildFire PreQual processing failed', [
              'error' => $e->getMessage(),
              'context' => $e->getContext()
            ]);
            return $this->errorResponse($response, 'Processing failed', 500);
        } catch (\Throwable $e) {
            $this->logger->error('Unexpected error in WildFire PreQual', [
              'error' => $e->getMessage(),
              'trace' => $e->getTraceAsString()
            ]);
            return $this->errorResponse($response, 'Internal server error', 500);
        }
    }

    /**
     * Handle legacy pull request (direct bureau pull)
     */
    public function handleLegacyPull(Request $request, Response $response): Response
    {
        try {
            $requestData = $this->getRequestData($request);

            // Extract PII and bureau information
            $bureau = $requestData['bureau'] ?? 'experian';
            $pii = $requestData['pii'] ?? [];
            $scoreModel = $requestData['score_model'] ?? 'VANTAGE';

            // Build applicant from PII data
            $applicant = $this->buildApplicantFromPII($pii);

            // Process through automation service
            $automationRequestData = [
              'applicant' => $applicant->toArray(),
              'vehicle' => ['vin' => '', 'year' => 2020, 'make' => '', 'model' => '', 'mileage' => 0, 'loan_amount' => 0],
              'preferred_bureau' => $bureau
            ];

            $result = $this->automationService->processPreQual($automationRequestData);

            // Format in legacy WildFire format
            $wildFireResponse = $this->wildFireFormatter->formatToWildFire(
              $result->creditProfile,
              [], // Raw bureau data
              $applicant->hasCoApplicant()
            );

            $responseData = [
              'success' => true,
              'error' => null,
              'bureau_payload' => [],
              'payload' => $wildFireResponse
            ];

            $response->getBody()->write(json_encode($responseData));
            return $response
              ->withHeader('Content-Type', 'application/json')
              ->withStatus(200);

        } catch (\Throwable $e) {
            $this->logger->error('Legacy pull failed', [
              'error' => $e->getMessage()
            ]);

            return $this->errorResponse($response, $e->getMessage(), 500);
        }
    }

    private function getApplicationPayload(Request $request): array
    {
        $body = (string) $request->getBody();
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new ValidationException('Invalid JSON in request body');
        }

        return $data;
    }

    private function getRequestData(Request $request): array
    {
        $body = (string) $request->getBody();

        // Try to parse as JSON first
        $data = json_decode($body, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $data;
        }

        // Fallback to parsing legacy format
        return $this->parseLegacyRequest($body);
    }

    private function parseLegacyRequest(string $body): array
    {
        // Handle legacy request format if needed
        // This would parse the old WildFire format
        return [];
    }

    /**
     * @throws \WF\API\Automation\Exceptions\ValidationException
     */
    private function buildApplicantFromPII(array $pii): Applicant
    {
        $primary = $pii['primary'] ?? [];
        $secondary = $pii['secondary'] ?? [];
        $hasCoApp = !empty($secondary);

        $coApplicantData = null;
        if ($hasCoApp) {
            $coApplicantData = [
              'first_name' => $secondary['first'] ?? '',
              'last_name' => $secondary['last'] ?? '',
              'ssn' => $secondary['ssn'] ?? '',
              'dob' => $secondary['dob'] ?? '',
              'address' => $secondary['address'] ?? '',
              'city' => $secondary['city'] ?? '',
              'state' => $secondary['state'] ?? '',
              'zip' => $secondary['zip'] ?? ''
            ];
        }

        return Applicant::fromArray([
          'monthly_income' => 0, // Not in PII
          'employment_type' => 'other',
          'state' => $primary['state'] ?? '',
          'first_name' => $primary['first'] ?? '',
          'last_name' => $primary['last'] ?? '',
          'ssn' => $primary['ssn'] ?? '',
          'address' => $primary['address'] ?? '',
          'city' => $primary['city'] ?? '',
          'zip_code' => $primary['zip'] ?? '',
          'date_of_birth' => $primary['dob'] ?? '',
          'co_applicant' => $coApplicantData
        ]);
    }

    private function errorResponse(Response $response, string $message, int $status): Response
    {
        $errorData = [
          'success' => false,
          'error' => $message,
          'bureau_payload' => [],
          'payload' => []
        ];

        $response->getBody()->write(json_encode($errorData));
        return $response
          ->withHeader('Content-Type', 'application/json')
          ->withStatus($status);
    }
}
