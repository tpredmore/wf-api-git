<?php

declare(strict_types=1);

namespace WF\API\Automation\Clients;

use WF\API\Automation\Exceptions\BureauApiException;
use GuzzleHttp\Exception\GuzzleException;

class TransUnionClient extends AbstractBureauClient
{
    protected function authenticate(): string
    {
        // TransUnion might use basic auth or different token flow
        try {
            $response = $this->httpClient->post($this->config['endpoint'] . '/auth', [
              'json' => [
                'username' => $this->config['username'],
                'password' => $this->config['password'],
              ],
            ]);

            $data = json_decode((string) $response->getBody(), true);

            if (!isset($data['token'])) {
                throw new BureauApiException('Failed to obtain TransUnion token');
            }

            return $data['token'];

        } catch (GuzzleException $e) {
            throw new BureauApiException('TransUnion authentication failed: ' . $e->getMessage(), 0, $e);
        }
    }

    protected function buildRequestPayload(array $consumers): array
    {
        $primary = $consumers[0];

        return [
          'accountName' => $this->config['account_name'] ?? '',
          'accountNumber' => $this->config['account_number'] ?? '',
          'memberCode' => $this->config['member_code'] ?? '',
          'subject' => [
            'name' => [
              'unparsedName' => $primary['firstName'] . ' ' . $primary['lastName'],
            ],
            'ssn' => $primary['ssn'],
            'dateOfBirth' => $primary['dob'],
            'address' => [
              'streetName' => $primary['address'],
              'city' => $primary['city'],
              'state' => $primary['state'],
              'zipCode' => $primary['zip'],
            ],
          ],
          'type' => 'identity',
          'showVantageScore' => true,
        ];
    }

    protected function makeRequest(array $payload): array
    {
        try {
            $response = $this->httpClient->post($this->config['endpoint'] . '/creditreport', [
              'headers' => [
                'Authorization' => "Bearer {$this->accessToken}",
                'Content-Type' => 'application/json',
              ],
              'json' => $payload,
            ]);

            return json_decode((string) $response->getBody(), true);

        } catch (GuzzleException $e) {
            throw new BureauApiException('TransUnion request failed: ' . $e->getMessage(), 0, $e);
        }
    }

    public function getName(): string
    {
        return 'TransUnion';
    }
}
