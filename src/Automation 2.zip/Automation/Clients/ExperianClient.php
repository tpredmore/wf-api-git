<?php

declare(strict_types=1);

namespace WF\API\Automation\Clients;

use WF\API\Automation\Exceptions\BureauApiException;
use GuzzleHttp\Exception\GuzzleException;

class ExperianClient extends AbstractBureauClient
{
    protected function authenticate(): string
    {
        try {
            $response = $this->httpClient->post($this->config['token_endpoint'], [
              'form_params' => [
                'grant_type' => 'client_credentials',
                'client_id' => $this->config['client_id'],
                'client_secret' => $this->config['client_secret'],
              ],
            ]);

            $data = json_decode((string) $response->getBody(), true);

            if (!isset($data['access_token'])) {
                throw new BureauApiException('Failed to obtain Experian access token');
            }

            return $data['access_token'];

        } catch (GuzzleException $e) {
            throw new BureauApiException('Experian authentication failed: ' . $e->getMessage(), 0, $e);
        }
    }

    protected function buildRequestPayload(array $consumers): array
    {
        $primary = $consumers[0];

        return [
          'consumerPii' => [
            'primaryApplicant' => [
              'name' => [
                'firstName' => $primary['firstName'],
                'lastName' => $primary['lastName'],
              ],
              'ssn' => $primary['ssn'],
              'dob' => $primary['dob'],
              'currentAddress' => [
                'line1' => $primary['address'],
                'city' => $primary['city'],
                'state' => $primary['state'],
                'zipCode' => $primary['zip'],
              ],
            ],
          ],
          'requestor' => [
            'subscriberCode' => $this->config['subscriber_code'] ?? '',
          ],
          'permissiblePurpose' => [
            'type' => 'ApplicationForCredit',
            'terms' => 'Individual',
          ],
          'addOns' => [
            'scoreCard' => 'FICO',
          ],
        ];
    }

    protected function makeRequest(array $payload): array
    {
        try {
            $response = $this->httpClient->post($this->config['report_endpoint'], [
              'headers' => [
                'Authorization' => "Bearer {$this->accessToken}",
                'Content-Type' => 'application/json',
              ],
              'json' => $payload,
            ]);

            return json_decode((string) $response->getBody(), true);

        } catch (GuzzleException $e) {
            throw new BureauApiException('Experian request failed: ' . $e->getMessage(), 0, $e);
        }
    }

    public function getName(): string
    {
        return 'Experian';
    }
}
