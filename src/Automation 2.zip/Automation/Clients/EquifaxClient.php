<?php

declare(strict_types=1);

namespace WF\API\Automation\Clients;

use WF\API\Automation\Exceptions\BureauApiException;

class EquifaxClient extends AbstractBureauClient
{

    /**
     * @throws \WF\API\Automation\Exceptions\BureauApiException
     */
    protected function authenticate(): string
    {
        try {
            $response = $this->httpClient->post($this->config['token_endpoint'],
              [
                $this->config['client_id'],
                $this->config['client_secret'],
              ],
              [
                'grant_type' => 'client_credentials',
                'scope' => 'https://api.equifax.com/business/consumer-credit/v1',
              ]
            );

            $data = json_decode((string) $response->getBody(), true);

            if (!isset($data['access_token'])) {
                throw new BureauApiException('Failed to obtain Equifax access token');
            }

            return $data['access_token'];

        } catch (\Exception $e) {
            throw new BureauApiException('Equifax authentication failed: ' . $e->getMessage(), 0, $e);
        }
    }

    protected function buildRequestPayload(array $consumers): array
    {
        return [
          'consumers' => $consumers,
          'customerReferenceIdentifier' => 'JSON',
          'customerConfiguration' => [
            'equifaxUSConsumerCreditReport' => [
              'memberNumber' => $this->config['member_number'],
              'securityCode' => $this->config['security_code'],
              'codeDescriptionRequired' => true,
              'ECOAInquiryType' => count($consumers) > 1 ? 'Co-applicant' : 'Individual',
              'models' => [['identifier' => $this->config['model_id']]],
              'optionalFeatureCode' => [$this->config['optional_feature']],
            ],
          ],
        ];
    }

    /**
     * @throws \WF\API\Automation\Exceptions\BureauApiException
     */
    protected function makeRequest(array $payload): array
    {
        try {
            $response = $this->httpClient->post($this->config['report_endpoint'],
              $payload,
              [
                'Authorization' => "Bearer {$this->accessToken}",
                'Content-Type' => 'application/json',
              ]
            );

            return json_decode((string) $response->getBody(), true);

        } catch (\Exception $e) {
            throw new BureauApiException('Equifax request failed: ' . $e->getMessage(), 0, $e);
        }
    }

    public function getName(): string
    {
        return 'Equifax';
    }
}
