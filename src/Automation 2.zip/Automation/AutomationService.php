<?php

declare(strict_types=1);

namespace WF\API\Automation;

use WF\API\Automation\Contracts\PreQualEngineInterface;
use WF\API\Automation\Models\Applicant;
use WF\API\Automation\Models\Vehicle;
use WF\API\Automation\Models\PreQualResult;
use WF\API\Automation\Exceptions\AutomationException;
use Log;

/**
 * Main orchestrator for the Automation PreQual engine.
 * Coordinates soft pulls, risk scoring, and lender matching.
 */
class AutomationService
{
    public function __construct(
      private PreQualEngineInterface $preQualEngine,
      private Log $logger
    ) {}

    /**
     * Process a pre-qualification request.
     *
     * @throws \WF\API\Automation\Exceptions\AutomationException
     */
    public function processPreQual(array $requestData): PreQualResult
    {
        try {
            $this->logger->info('Starting pre-qualification process', print_r([
              'request_id' => $requestData['request_id'] ?? 'unknown'
            ],true));

            // Validate and transform input data
            $applicant = Applicant::fromArray($requestData['applicant'] ?? []);
            $vehicle = Vehicle::fromArray($requestData['vehicle'] ?? []);

            // Execute pre-qualification
            $result = $this->preQualEngine->evaluate($applicant, $vehicle, $requestData);

            $this->logger->info('Pre-qualification completed successfully', print_r([
              'result_tier' => $result->getRiskTier(),
              'matched_lenders' => count($result->getMatchedLenders())
            ],true));

            return $result;

        } catch (\Throwable $e) {
            $this->logger->error('Pre-qualification failed', [
              'error' => $e->getMessage(),
              'trace' => $e->getTraceAsString()
            ]);

            throw new AutomationException('Pre-qualification process failed', 0, $e);
        }
    }
}
